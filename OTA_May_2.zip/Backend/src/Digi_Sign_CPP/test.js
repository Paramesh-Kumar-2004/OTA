import {execute} from "./CPP_Run_Command.js"


await execute()

// export async function test(){
// 	await execute()
// }

// test()



 
