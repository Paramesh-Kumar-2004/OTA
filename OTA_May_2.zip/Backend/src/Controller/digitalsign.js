import {execute} from "../Digi_Sign_CPP/CPP_Run_Command.js"


// await execute()

export async function digitalsign(){
	console.log("\nEntered Into Digital Sign Creation Function")
	await execute()
	console.log("Exit Into Digital Sign Creation Function\n")
}

// test()

 